[item-name]
iron-chest-II = Iron Chest II
[entity-name]
iron-chest-II = Iron Chest II
[technology-name]
iron-chest-II = Iron Chest II
[technology-discription]
iron-chest-II = Iron Chest II