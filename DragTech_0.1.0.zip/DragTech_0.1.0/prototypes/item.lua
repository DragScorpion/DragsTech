data:extend({
{
    type = "item",
    name = "iron-chest-II",
    icon = "__base__/graphics/icons/iron-chest.png",
    flags = {"goes-to-quickbar"},
    subgroup = "storage",
    order = "a[items]-b[iron-chest-II]",
    place_result = "iron-chest-II",
    stack_size = 500
  }
  
  })