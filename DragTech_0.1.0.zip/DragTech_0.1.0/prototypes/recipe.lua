data:extend({

{
    type = "recipe",
    name = "iron-chest",
    enabled = true,
    ingredients = {{"iron-plate", 2}},
    result = "iron-chest"
  }
 })